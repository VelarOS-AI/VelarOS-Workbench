# VelarOS-Kernel

VelarOS-Kernel 是 VelarOS 生态的共享内核。它位于**上层产品应用**与**底层 Mod** 之间:

- **对上**,为 VelarOS-Desktop、Workbench、浏览器桥接、CLI 等产品提供稳定的 Client API。
- **对下**,为文件、浏览器、Agent、模型、记忆等 Mod 提供稳定的 Module SDK。
- **内部**,负责模块加载、能力路由、RPC 通信、权限治理、生命周期、状态、事件、Session、Run、单实例运行与本地服务发现。

> **2026-07-27 边界**:Kernel 只对外发布三个包。Protocol、Host、Runtime、RPC、Daemon、Launcher 是内部基础设施,住在 `src/`,不发布。Core 与 Agent 已迁出本仓(见下)。

## 两个开发入口 + 一个运维包

| 包 | 面向 | 职责 |
| --- | --- | --- |
| `@velaros-ai/kernel-client` | 产品开发者 | 发现、连接、调用共享 Kernel。产品接入的**唯一主要入口**。 |
| `@velaros-ai/kernel-sdk` | Mod 开发者 | 声明 Module、Capability、依赖、权限、事件、状态与生命周期。Mod 开发的**唯一主要入口**。 |
| `@velaros-ai/kernel-updater` | 运维/Launcher | 共享 Kernel Runtime 的下载、校验、并排安装、版本切换与回滚。 |

产品不应直接依赖 Kernel Host、Runtime 或任何具体 Mod 实现;Mod 不应直接访问 Kernel Host、Service Registry 或其他内部实现。

## 目录结构

```text
packages/
├── kernel-client/       # 产品接入(含 wire 协议契约的唯一实现)
├── kernel-sdk/          # Mod 开发契约
└── kernel-updater/      # 安装 / 切换 / 回滚

src/                     # Kernel 内部基础设施,不发布
├── protocol/            # 协议桶文件(实现在 kernel-client/src/protocol)
├── host/                # KernelModuleHost、依赖解析、服务注册、权限、事件、状态、隔离
├── runtime/             # KernelService、identity registry
├── rpc/                 # 本地 RPC server 与帧解码
├── daemon/              # 单实例 daemon、锁、descriptor 发布、进程装配
├── launcher/            # 版本选择、进程启动、发现、握手、重启
├── internal/            # 内部测试适配层(进程内 transport)
└── main.ts              # Kernel 进程入口
```

## 依赖方向

```text
kernel-client ──── protocol contracts
kernel-sdk ─────── (无 Runtime 依赖)
kernel-updater ─── (独立的文件、下载、版本与校验逻辑)

Kernel internal host ────── kernel-sdk
Kernel internal runtime ─┬─ protocol contracts
                         ├─ kernel-sdk
                         └─ internal host

产品 / CLI ─── kernel-client
Mod ────────── kernel-sdk
```

禁止出现(由 `scripts/check-arch-boundaries.mjs` 与 ESLint 双重拦截):

```text
kernel-client → kernel host / runtime / rpc / daemon / launcher
kernel-sdk    → kernel-client / kernel-updater / runtime
Mod           → kernel host internal
产品           → kernel host internal
```

### 协议的单一事实来源

wire schema 只有**一份**实现,位于 `packages/kernel-client/src/protocol`。Client 与 Kernel 内部 runtime 消费同一份 zod 定义:Kernel 内部通过 `src/protocol` 桶文件引入,禁止另写一份 request/response 类型。实现落在可发布的 Client 一侧,是因为 Client 是已发布包而 `src/` 不是——依赖方向仍然合规。

握手 schema 刻意放宽到 `z.number().int().positive()`,让**异版本对端的握手先能被解析**,兼容性判定交给逻辑层的滑动窗口 (`negotiateKernelProtocol`);协商成功之后流转的业务帧才逐帧盖章精确匹配当前版本。

## 什么必须注入

- Workspace、Model、Computer、System、Office、Browser、Memory/Knowledge 都**不是**内核实现,必须作为独立包通过端口注入。
- Desktop、Workbench 与其他产品只在 composition root 选择与配置这些模块。
- Kernel 三包的源码与 manifest 都不得反向依赖任何具体能力包。

## 已迁出本仓

| 包 | 新仓库 |
| --- | --- |
| `@velaros-ai/core` | `VelarOS-Core` |
| `@velaros-ai/agent-protocol`、`@velaros-ai/agent-runtime` | `VelarOS-Agent` |

包名与公共 API 不变。

## 边界原则

- 产品域不进入 Kernel wire protocol;调用方只传不透明的 `ScopeRef` / `ResourceRef`。
- 权限默认拒绝,具体能力不能绕过 Kernel permission broker 和生命周期。
- 运行中的 turn 使用能力快照;注册表变化只影响后续 turn。
- Launcher 与 Updater 职责分离:Launcher 选版本、起进程、等 descriptor、握手与健康校验;Updater 下载、校验、并排安装、切 current、回滚。应用可以请求它们执行操作,但不能直接覆盖 Kernel 可执行文件。
- 每个对外包必须能独立 install、build、test、publish。

## 常用命令

```bash
bun install
bun run build          # 先按拓扑构建三包,再构建内部 src
bun run typecheck
bun run test
bun run lint
bun run check:schemas  # wire 形状保形
bun run check:arch     # 架构边界哨兵(基线=零违规)
bun run check:consumer # 包元数据、文档与 tarball 消费面
bun run check          # 以上全部
bun run release:dry-run
```

协议形状有意变更时:

```bash
SCHEMA_BASELINE_UPDATE=1 bun scripts/check-schemas.mjs
```

必须审阅 `baselines/kernel-wire-schema-snapshot.json` 的差异,并同步协议版本说明。

## 迁移

从 0.2.x 升级(`kernel-protocol` / `kernel-host` / `kernel-service` 已硬中断下线):见 [docs/migration-0.3.md](./docs/migration-0.3.md)。
